package numbersprograms;

public class GivenNumberBuzzNumber {
	public static void main(String[] args) {
		int n=49;
		if(n%7==0||n%10==0)
		{
			System.out.println("The Given Number is Buzz Number");
		}
		else
		{
			System.out.println("The Given Number is not a Buzz Number");
		}
	}

}
